package org.bank;
import java.util.*;
public class Money extends Valid {

	public static void moneydep(BankApp m)
	{
		Scanner mp=new Scanner(System.in);
		System.out.println("WHICH TYPE OF DEPOSIT PRESS");
		System.out.println("ATM            1");
		System.out.println("GOOGLE PAY     2");
		System.out.println("ACCOUNT TRANS  3");
		int mn=mp.nextInt();
		
		if(mn==1)
		{
			m.arr[m.k]="ATM          ";
		}
		if(mn==2)
		{
			m.arr[m.k]="GOOGLE PAY   ";
		}
		if(mn==3)
		{
			m.arr[m.k]="ACCOUNT TRANS";
		}
		m.arr1[m.k]="DEPOSIT   ";
		
		System.out.println("ENTER THE AMOUNT");
		int am=mp.nextInt();
		m.arr2[m.k]=am;
		
		m.inamout+=am;
		m.bal[m.k]=m.inamout;
		m.k++;
			System.out.println("YOUR AMOUNT IS DEPOSITED");
			System.out.println("TOTAL BALANCE:"+m.inamout);
		
	}
	public static void moneywith(BankApp m)
	{
		Scanner mp=new Scanner(System.in);System.out.println("WHICH TYPE OF DEPOSIT PRESS");
		System.out.println("ATM            1");
		System.out.println("GOOGLE PAY     2");
		System.out.println("ACCOUNT TRANS  3");
		int mn=mp.nextInt();
		if(mn==1)
		{
			m.arr[m.k]="ATM          ";
		}
		if(mn==2)
		{
			m.arr[m.k]="GOOGLE PAY   ";
		}
		if(mn==3)
		{
			m.arr[m.k]="ACCOUNT TRANS";
		}
		m.arr1[m.k]="WITHDRAWAL";
		boolean mpo=true;
		while(mpo)
		{
	       System.out.println("ENTER THE AMOUNT");
		    long am=mp.nextLong();
		
		   if(am<=m.inamout)
	     	{
			m.arr2[m.k]= am;
			m.inamout-=am;
			m.bal[m.k]=m.inamout;
			m.k++;

			System.out.println("YOUR AMOUNT IS WITHDRAWAL");
			System.out.println("YOUR TOTAL BALANCE:"+m.inamout);
			mpo=false;
		   }
	    	else
			System.out.println("INSUFFICIENT MONEY");
		}
		
	}
}
