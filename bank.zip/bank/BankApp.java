package org.bank;

import java.util.*;


public class BankApp extends BankA {
		private static char[][] cus;
		String name;
	long accountno;
	long inamout;
	int age;
	String password;
    int count=0;
    int passcha=0;
    String[] arr=new String[15];
    String[] arr1=new String[15];
    long arr2[]=new long[15];
    long bal[]=new long[15];
    int k=0;
    
	public BankApp(String na,long acc,long into,int age,String pass,int c,int k1)
	{
		name=na;
		accountno=acc;
		inamout=into;
		this.age=age;
		password=pass;
		count =0;
	    count=c;
	    k=k1;
		
	}
	public static void main(String[] args) {
		Scanner mp=new Scanner(System.in);
		
     ArrayList<BankApp> cus=new ArrayList<BankApp>();
     cus.add(new BankApp("james",123444,500,23,"james#$%",0,0));
     cus.add(new BankApp("anitha",123445,500,20,"anit123#",0,0));
     cus.add(new BankApp("jeya",123446,500,20,"jeya#$2",0,0));
    //System.out.println(BankApp.cus[0]);
    
   
     int i=1;
     while(i!=0)
     {
    	 System.out.println("LOGIN           1");
          System.out.println("CREATE ACCOUNT 2");
          System.out.println("EXIT           0");
           int n=mp.nextInt();
           if(n==0)
        	   break;
    	switch(n)
    	{
    	case 1:
    	
    		        System.out.println("ENTER THE ACCOUNT NUMBER");
    	              long acc=mp.nextLong();
    	              for(int s=0;s<100;s++)
    {  
    	            	  int f=0;
    	  for(BankApp m:cus)
    	    {
    	     	  if(m.accountno==acc)
    	         	{      System.out.println("ENTER THE PASSWORD");
    	  	               String mo=mp.next();
    	  	               m.count=0;
    		               boolean nbt =true;
    		             while(nbt)
    		           {
    		                   if(mo.equals(m.password))
    	                 	{
    		                	   mac(m);
    		                       System.out.println("DO YOU WANT CONTINUE PRESS 1");
    		                       int nbh=mp.nextInt();
    		                       if(nbh==1)
    		                    	   nbt=true;
    		                       else
    		                    	   nbt=false;
    		                }
    		                 else if(m.count<2)
    	                     {
    		                 	System.out.println("RE ENTER PASSWORD");
    		                 	mo=mp.next();
    		                 	m.count++;
    	                     }
    		                else
    		                  { 
    		                	System.out.println("GOTO CHANGE PASSWORD");
    		                    m.count=0;
    		                    m.passcha++;
    		                    changepass(m);
    		                    }
    	                 }
    		             f=1;
    			       break;
    	         	}
                       
            }
    	  if(f==0)
    	  {
   	          System.out.println("RE ENTER ACCOUNT NUMBER");
   	          acc=mp.nextLong(); 
    	  }
    	  else
    		  break;
    	        
     }
    	      
    	   break;   
    	  case 2:create(cus);
    	  break;
     }
    	
  }
    
}
	public static void create(ArrayList<BankApp> cus)
	{ Scanner mp=new Scanner(System.in);
		System.out.println("ENTER THE CUSTOMER NAME");
		String nan=mp.next();
		System.out.println("ENTER THE ACCOUNT NUMBER");
		long b=mp.nextInt();
		System.out.println("ENTER THE AGE");
		int bnm=mp.nextInt();
		System.out.println("ENTER THE PASSWORD");
		System.out.println("YOUR PASSWORD CONTAIN EXPRESSION ORDER");
		String pass=mp.next();
		while(true)
		{
		if(check(pass))
		{
		    System.out.println("YOUR PASSWORD IS ACCEPTABLE");
		    System.out.println();
		    break;
		}
		else
		System.out.println("RE ENTER PASSWORD");
		 pass=mp.next();
		}

		cus.add(new BankApp(nan,b,500,bnm,pass,0,0));
		System.out.println("SUCCESSFULLY CREATED");
	     	
		System.out.println();
		return;
	}
	public static void view(BankApp m)
	{
		System.out.println("NAME:                "+m.name);
		System.out.println("ACCOUNT NUMBER:      "+m.accountno);
		System.out.println("AGE:                 "+m.age);
		System.out.println("AMOUNT:              "+m.inamout);
		System.out.println("PASSEORD:            "+m.password);
		System.out.println("COUNT                "+m.count);
		System.out.println("PASSWORD CHANGE:     "+m.passcha);
		System.out.println();
		System.out.println("METHOD                 TRANS                 AMOUNT            BALANCE");
		
		for(int i=0;i<m.k;i++)
		{
			System.out.println(m.arr[i]+"         "+m.arr1[i]+"             "+m.arr2[i]+"            "+m.bal[i]);
			try{Thread.sleep(1000);}catch(Exception o) {}
		}
		System.out.println();
	}
public static void mac(BankApp m)
{
Scanner mp=new Scanner(System.in);
    System.out.println("VIEW DETAILS   1");
    System.out.println("MONEY DEPOSIT  2");
    System.out.println("MONEY WITHDRAW 3");
int sw2=mp.nextInt();
  switch(sw2)
   {
  case 1:view(m);
   break;
  case 2:moneydep(m);
  break;
  case 3:moneywith(m);
  break;
 default:break;
 }
}

}
