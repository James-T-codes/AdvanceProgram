package org.bank;

import java.util.*;
public class BankA extends Money {

	public static boolean check(String pass)
	{
		char arr[]=pass.toCharArray();
		if(arr.length<6)
			return false;
		int i,j;
		boolean k=false,m=false,y=false,x=false;
		for(i=0;i<arr.length;i++)
		{
			if(arr[i]<='z'&&arr[i]>='a')
			{
				k=true;
			}
			if(arr[i]<='Z'&&arr[i]>='A')
			{
				m=true;
			}
			if(arr[i]<='9'&&arr[i]>='0')
			{
				y=true;
			}
		}
		if(k&&m&&y)
		{
			return true;
		}
		return false;
	}
	public static boolean changepass(BankApp m)
	{
		Scanner mp=new Scanner(System.in);
		System.out.println("ENTER THE PASSWORD");
		System.out.println("YOUR PASSWORD CONTAIN EXPRESSION ORDER");
		String pass=mp.next();
		while(true)
		{
		if(check(pass))
		{
			m.password=pass;
		    System.out.println("YOUR PASSWORD IS ACCEPTABLE");
		    return true;
		}
		else
		{
		System.out.println("RE ENTER PASSWORD");
		 pass=mp.next();
		}
		}
	
	}
}
