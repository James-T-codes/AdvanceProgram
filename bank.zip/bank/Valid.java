package org.bank;

import java.util.*;
public class Valid {

	public static void Passvalid(BankApp m)
	{
		Scanner mp=new Scanner(System.in);
		   
	}
}
